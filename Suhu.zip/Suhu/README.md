<<<<<<< HEAD
# suhu

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
=======
# Flutter_Konversi_Suhu
The Flutter Suhu Konverter is a mobile application designed to simplify temperature conversion tasks. Developed using the Flutter framework, this app provides an intuitive and user-friendly interface, making it easy for users to convert temperatures between different units.
>>>>>>> 824190231e3b2c0d13644ba0480b554e6f3ecf4a
# flutter-suhu
