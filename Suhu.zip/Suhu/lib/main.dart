// import 'package:flutter/material.dart';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Konversi Suhu',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: SuhuConverter(),
//     );
//   }
// }

// class SuhuConverter extends StatefulWidget {
//   @override
//   _SuhuConverterState createState() => _SuhuConverterState();
// }

// class _SuhuConverterState extends State<SuhuConverter> {
//   double inputSuhu = 0;
//   double outputSuhu = 0;
//   String selectedInputUnit = 'Celcius';
//   String selectedOutputUnit = 'Celcius';

//   final List<String> units = ['Celcius', 'Fahrenheit', 'Kelvin', 'Reamur'];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Konversi Suhu'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             TextField(
//               keyboardType: TextInputType.number,
//               onChanged: (value) {
//                 setState(() {
//                   inputSuhu = double.tryParse(value) ?? 0;
//                 });
//               },
//               decoration: InputDecoration(labelText: 'Masukkan Suhu'),
//             ),
//             SizedBox(height: 16),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 DropdownButton<String>(
//                   value: selectedInputUnit,
//                   onChanged: (value) {
//                     setState(() {
//                       selectedInputUnit = value!;
//                     });
//                   },
//                   items: units.map((unit) {
//                     return DropdownMenuItem<String>(
//                       value: unit,
//                       child: Text(unit),
//                     );
//                   }).toList(),
//                 ),
//                 ElevatedButton(
//                   onPressed: () {
//                     convertSuhu();
//                   },
//                   child: Text('Konversi'),
//                 ),
//                 DropdownButton<String>(
//                   value: selectedOutputUnit,
//                   onChanged: (value) {
//                     setState(() {
//                       selectedOutputUnit = value!;
//                     });
//                   },
//                   items: units.map((unit) {
//                     return DropdownMenuItem<String>(
//                       value: unit,
//                       child: Text(unit),
//                     );
//                   }).toList(),
//                 ),
//               ],
//             ),
//             SizedBox(height: 16),
//             Text('Hasil Konversi: $outputSuhu $selectedOutputUnit'),
//           ],
//         ),
//       ),
//     );
//   }

//   void convertSuhu() {
//     double result = inputSuhu;

//     if (selectedInputUnit == 'Celcius') {
//       if (selectedOutputUnit == 'Fahrenheit') {
//         result = (inputSuhu * 9 / 5) + 32;
//       } else if (selectedOutputUnit == 'Kelvin') {
//         result = inputSuhu + 273.15;
//       } else if (selectedOutputUnit == 'Reamur') {
//         result = inputSuhu * 4 / 5;
//       }
//     } else if (selectedInputUnit == 'Fahrenheit') {
//       if (selectedOutputUnit == 'Celcius') {
//         result = (inputSuhu - 32) * 5 / 9;
//       } else if (selectedOutputUnit == 'Kelvin') {
//         result = (inputSuhu - 32) * 5 / 9 + 273.15;
//       } else if (selectedOutputUnit == 'Reamur') {
//         result = (inputSuhu - 32) * 4 / 9;
//       }
//     } else if (selectedInputUnit == 'Kelvin') {
//       if (selectedOutputUnit == 'Celcius') {
//         result = inputSuhu - 273.15;
//       } else if (selectedOutputUnit == 'Fahrenheit') {
//         result = (inputSuhu - 273.15) * 9 / 5 + 32;
//       } else if (selectedOutputUnit == 'Reamur') {
//         result = (inputSuhu - 273.15) * 4 / 5;
//       }
//     } else if (selectedInputUnit == 'Reamur') {
//       if (selectedOutputUnit == 'Celcius') {
//         result = inputSuhu * 5 / 4;
//       } else if (selectedOutputUnit == 'Fahrenheit') {
//         result = (inputSuhu * 9 / 4) + 32;
//       } else if (selectedOutputUnit == 'Kelvin') {
//         result = (inputSuhu * 5 / 4) + 273.15;
//       }
//     }

//     setState(() {
//       outputSuhu = result;
//     });
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatefulWidget {
//   @override
//   _MyAppState createState()-> _MyAppState();

// }





// 

import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Konversi Suhu',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SuhuConverter(),
    );
  }
}

class SuhuConverter extends StatefulWidget {
  @override
  _SuhuConverterState createState() => _SuhuConverterState();
}

class _SuhuConverterState extends State<SuhuConverter> {
  TextEditingController inputController = TextEditingController();
  ConversionResult conversionResult = ConversionResult(); // Objek untuk menyimpan hasil konversi
  bool hasConverted = false; // Flag untuk menunjukkan apakah sudah dilakukan konversi

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Konversi Suhu'),
        backgroundColor: Colors.lightBlue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: inputController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: 'Masukkan Suhu (Celcius)'),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Text('Kelvin'),
                        Text('${conversionResult.kelvinResult}'),
                      ],
                    ),
                    Column(
                      children: [
                        Text('Fahrenheit'),
                        Text('${conversionResult.fahrenheitResult}'),
                      ],
                    ),
                    Column(
                      children: [
                        Text('Reamur'),
                        Text('${conversionResult.reamurResult}'),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    convertSuhu();
                  },
                  child: Text('Konversi'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.lightBlue,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void convertSuhu() {
    double inputSuhu = double.tryParse(inputController.text) ?? 0;

    conversionResult.kelvinResult = inputSuhu + 273.15;
    conversionResult.fahrenheitResult = (inputSuhu * 9 / 5) + 32;
    conversionResult.reamurResult = inputSuhu * 4 / 5;

    // Perbarui nilai input dan hasil perhitungan
    setState(() {});
  }
}

class ConversionResult {
  double kelvinResult = 0;
  double fahrenheitResult = 0;
  double reamurResult = 0;
}